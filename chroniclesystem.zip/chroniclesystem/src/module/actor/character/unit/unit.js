import SystemUtils from "../../../../util/systemUtils.js";
import { CharacterBase } from "../character-base.js";
import { ChronicleSystem } from "../../../system/ChronicleSystem.js";
import { getCommander } from "./helpers.js";
import {
    addTransformer,
    getAllTransformers,
    getTransformation
} from "../transformers.js";
import {
    CHARACTER_ATTR_CONSTANTS,
    EQUIPPED_CONSTANTS,
    KEY_CONSTANTS
} from "../../../constants.js";
import { getData } from "../../../common.js";

/**
 * The Actor entity for handling warfare units.
 *
 * @category Actor
 */
export class Unit extends CharacterBase {

    prepareData() {
        super.prepareData();

        // get all active transformers
        this.system.transformers = getAllTransformers(this);

        // get damage resistance
        this.system.damageResistance = getTransformation(
            this, "modifiers", CHARACTER_ATTR_CONSTANTS.DAMAGE_TAKEN,
            false, false
        ).total;
    }

    calculateDerivedValues() {
        let data = getData(this);

        // commander
        data.commander = getCommander(this.getEmbeddedCollection("Item"));

        // current order
        data.currentOrder = this.getEmbeddedCollection("Item").find(
            (item) => item.type === 'order' && item.system.equipped === EQUIPPED_CONSTANTS.ORDER
        ) || null;

        // "equipped" hardcoded entities
        // formation
        data.equippedFormation = ChronicleSystem.formations.find(
            (item) => item.rating === data.currentFormation
        );

        // base combat defense
        data.derivedStats.combatDefense.value = this.calcCombatDefense();
        data.derivedStats.combatDefense.total = data.derivedStats.combatDefense.value
            + parseInt(data.derivedStats.combatDefense.modifier);
        // discrete defense
        // v. fighting
        data.discreteDefenses.vFighting.value = data.derivedStats.combatDefense.total;
        data.discreteDefenses.vFighting.modifier = this.getTransformation("modifiers",
            ChronicleSystem.modifiersConstants.COMBAT_DEFENSE_FIGHTING,
            false, true
        ).total;
        data.discreteDefenses.vFighting.total = data.discreteDefenses.vFighting.value
            + data.discreteDefenses.vFighting.modifier;
        // v. marksmanship
        data.discreteDefenses.vMarksmanship.value = data.derivedStats.combatDefense.total;
        data.discreteDefenses.vMarksmanship.modifier = this.getTransformation("modifiers",
            ChronicleSystem.modifiersConstants.COMBAT_DEFENSE_MARKSMANSHIP,
            false, true
        ).total;
        data.discreteDefenses.vMarksmanship.total = data.discreteDefenses.vMarksmanship.value
            + data.discreteDefenses.vMarksmanship.modifier;

        data.derivedStats.health.value = this.getAbilityValue(SystemUtils.localize(ChronicleSystem.keyConstants.ENDURANCE)) * 3;
        data.derivedStats.health.total = data.derivedStats.health.value + parseInt(data.derivedStats.health.modifier);

        // disorganisation
        data.disorganisation.value = this.getAbilityValue(SystemUtils.localize(ChronicleSystem.keyConstants.ENDURANCE));
        data.disorganisation.total = data.disorganisation.value + parseInt(data.disorganisation.modifier);

        // num of orders received / turn
        data.ordersReceived.value = 5;
        data.ordersReceived.total = data.ordersReceived.value + parseInt(data.ordersReceived.modifier);

        // discipline
        data.discipline.modifier = this.getTransformation("modifiers",
            ChronicleSystem.modifiersConstants.DISCIPLINE, false, true
        ).total;
        data.discipline.total = data.discipline.value + data.discipline.modifier;
        data.discipline.totalWithOrders = data.discipline.total
            + parseInt(data.discipline.ordersReceivedModifier);

        // training
        data.training.value = 4;
        data.training.total = data.training.value + parseInt(data.training.modifier);
    }
}
