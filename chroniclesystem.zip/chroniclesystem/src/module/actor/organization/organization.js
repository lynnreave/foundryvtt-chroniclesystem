import { ActorChronicle } from "../actor-chronicle.js";

/**
 * The Actor entity for handling organizations.
 *
 * @category Actor
 */
export class Organization extends ActorChronicle {
}
