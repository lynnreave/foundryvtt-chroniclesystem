import {ItemChronicle} from "./item-chronicle.js";

export class CSAbilityItem extends ItemChronicle {

}