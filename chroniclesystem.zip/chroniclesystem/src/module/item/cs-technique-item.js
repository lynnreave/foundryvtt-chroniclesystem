import {ItemChronicle} from "./item-chronicle.js";

export class CSTechniqueItem extends ItemChronicle {

}